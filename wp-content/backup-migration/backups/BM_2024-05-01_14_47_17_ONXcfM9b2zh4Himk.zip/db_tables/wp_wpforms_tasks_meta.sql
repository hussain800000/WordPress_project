/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpforms_tasks_meta`; */
/* PRE_TABLE_NAME: `1714574841_wp_wpforms_tasks_meta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1714574841_wp_wpforms_tasks_meta` ( `id` bigint(20) NOT NULL AUTO_INCREMENT, `action` varchar(255) NOT NULL, `data` longtext NOT NULL, `date` datetime NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1714574841_wp_wpforms_tasks_meta` (`id`, `action`, `data`, `date`) VALUES (1,'wpforms_process_forms_locator_scan','W10=','2024-04-26 13:29:04');
